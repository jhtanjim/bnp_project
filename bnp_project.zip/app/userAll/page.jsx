import React from "react";
import UserAll from "./userAll";

const page = () => {
  return (
    <div>
      <UserAll />
    </div>
  );
};

export default page;

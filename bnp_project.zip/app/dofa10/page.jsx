import React from "react";
import { Dofa10 } from "./dofa10";

const page = () => {
  return (
    <div className=" bg-[rgb(179,221,196)]">
      <div className="max-w-screen-xl lg:mx-auto mx-4 bg-[rgb(179,221,196)]">
        <Dofa10 />
      </div>
    </div>
  );
};

export default page;

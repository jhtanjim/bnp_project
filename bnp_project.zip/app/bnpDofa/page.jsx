import { BnpDofa } from "./bnpDofa";

const Page = () => {
  // Define the data to pass into the HoverEffect component

  return (
    <div className="container">
      {/* Pass the items data into the HoverEffect component */}

      <BnpDofa />
    </div>
  );
};

export default Page;

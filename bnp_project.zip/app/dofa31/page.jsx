import React from "react";
import { Dofa31 } from "./dofa31";

const page = () => {
  return (
    <div className=" bg-[rgb(179,221,196)]">
      <div className="max-w-screen-xl lg:mx-auto mx-4 bg-[rgb(179,221,196)]">
        <Dofa31 />
      </div>
    </div>
  );
};

export default page;

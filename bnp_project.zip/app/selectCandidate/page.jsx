import React from "react";
import SelectCandidate from "./selectCandidate";

const page = () => {
  return (
    <div>
      <SelectCandidate />
    </div>
  );
};

export default page;

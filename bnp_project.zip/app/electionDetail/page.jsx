// import React from "react";
// import ElectionDetail from "./electionDetail";

// const page = () => {
//   return (
//     <div>
//       <ElectionDetail />
//     </div>
//   );
// };

// export default page;

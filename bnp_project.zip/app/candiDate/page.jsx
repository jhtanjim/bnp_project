import React from "react";
import CandiDate from "./candiDate";

const page = () => {
  return (
    <div>
      <CandiDate />
    </div>
  );
};

export default page;

import React from "react";
import UpdateProfile from "./updateProfile";

const page = () => {
  return (
    <div>
      <UpdateProfile />
    </div>
  );
};

export default page;

import React from "react";
import About from "./about";
const page = () => {
  return (
    <div>
      <About></About>
    </div>
  );
};

export default page;

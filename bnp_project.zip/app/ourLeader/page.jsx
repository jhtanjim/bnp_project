import React from "react";
import OurLeader from "./ourLeader";

const page = () => {
  return (
    <div>
      <OurLeader />
    </div>
  );
};

export default page;

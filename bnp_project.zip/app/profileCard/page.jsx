import React from "react";
import ProfileCard from "./profileCard";

const page = () => {
  return (
    <div>
      <ProfileCard />
    </div>
  );
};

export default page;

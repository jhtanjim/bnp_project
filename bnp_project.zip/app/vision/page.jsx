import React from "react";
import Vision from "./vision";

const page = () => {
  return (
    <div>
      <Vision />
    </div>
  );
};

export default page;

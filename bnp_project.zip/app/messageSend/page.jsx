import React from "react";
import MessageSend from "./messageSend";

const page = () => {
  return (
    <div>
      <MessageSend />
    </div>
  );
};

export default page;

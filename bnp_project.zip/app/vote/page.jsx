// import React from "react";
// import Vote from "./vote";

// const page = () => {
//   return (
//     <div>
//       <Vote />
//     </div>
//   );
// };

// export default page;

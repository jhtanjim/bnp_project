import React from "react";
import Video from "./video";

const page = () => {
  return (
    <div>
      <Video />
    </div>
  );
};

export default page;

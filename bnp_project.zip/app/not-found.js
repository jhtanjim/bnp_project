import React from "react";

const NotFound = () => {
  return (
    <div>
      <h1>there has no requested page</h1>
    </div>
  );
};

export default NotFound;

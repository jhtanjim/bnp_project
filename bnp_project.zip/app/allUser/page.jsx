import React from "react";
import Alluser from "./allUser";

const page = () => {
  return (
    <div>
      <Alluser />
    </div>
  );
};

export default page;

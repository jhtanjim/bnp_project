import React from "react";

const Alluser = () => {
  return (
    <div>
      <h1>allUser</h1>
    </div>
  );
};

export default Alluser;

import React from "react";
import SignIn from "./signIn";

const page = () => {
  return (
    <div>
      <SignIn />
    </div>
  );
};

export default page;

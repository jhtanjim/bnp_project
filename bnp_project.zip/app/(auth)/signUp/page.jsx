import React from "react";
import SignUp from "./signUp";

const page = () => {
  return (
    <div>
      <SignUp />
    </div>
  );
};

export default page;

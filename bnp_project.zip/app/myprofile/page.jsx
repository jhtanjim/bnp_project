import React from "react";
import Myprofile from "./myprofile";

const page = () => {
  return (
    <div>
      <Myprofile />
    </div>
  );
};

export default page;

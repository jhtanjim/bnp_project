import React from "react";
import ApproveList from "./approveList";

const page = () => {
  return (
    <div>
      <ApproveList />
    </div>
  );
};

export default page;

import React from "react";
import Navbar from "./navbar";

const page = () => {
  return (
    <div>
      <Navbar />.
    </div>
  );
};

export default page;

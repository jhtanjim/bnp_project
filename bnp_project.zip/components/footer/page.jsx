import React from "react";
import Footer from "./footer";

const page = () => {
  return (
    <div>
      <Footer />
    </div>
  );
};

export default page;

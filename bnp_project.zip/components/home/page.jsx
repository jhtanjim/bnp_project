import Home from "@/app/page";
import React from "react";

const page = () => {
  return (
    <div>
      <Home />
    </div>
  );
};

export default page;

import React from "react";
import PrivateRoute from "./privateRoute ";

const page = () => {
  return (
    <div>
      <PrivateRoute />
    </div>
  );
};

export default page;
